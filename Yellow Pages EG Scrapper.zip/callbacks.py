from dash import Input, Output, State, ctx, dcc, html
import dash
import pandas as pd
from scraper import YellowPagesScraper

scraper = YellowPagesScraper()

def register_callbacks(app):
    @app.callback(
        [Output("data-table", "data"), Output("status-indicator", "children")],
        Input("start-btn", "n_clicks"),
        Input("stop-btn", "n_clicks"),
        Input("interval", "n_intervals"),
        State("keyword-input", "value"),
        prevent_initial_call=True
    )
    def handle_scraping(start_clicks, stop_clicks, n_intervals, keyword):
        triggered_id = ctx.triggered_id

        if triggered_id == "start-btn" and keyword:
            scraper.start_scraping(keyword)

        elif triggered_id == "stop-btn":
            scraper.stop_scraping()

        status_data = scraper.get_status()
        status_text = f"Status: {status_data['status']} | Companies Scraped: {status_data['scraped_count']}"

        return scraper.get_data(), status_text
